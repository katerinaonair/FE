module.exports = function print(msg){
  console.log('*******');
  console.log(msg);
  console.log('*******');
};
