const print = require('katovski-frame-print');

print('Hello NPM!');

/*
Expected Output:

**********
Hello NPM!
**********
*/
